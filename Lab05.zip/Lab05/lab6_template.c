#include "Timer.h"
#include "lcd.h"
#include "cyBot_Scan.h"
#include "uart.h"
#include "open_interface.h"
#include "movement.h"
#include "uart-interrupt.h"
#include <math.h>

#define REPLACEME 0

int main(void) {
    timer_init();
    lcd_init();
    uart_init();

    cyBOT_init_Scan(0b0111);

    right_calibration_value = 337750;
    left_calibration_value = 1330000;

    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);

        int i;
        int edges[6] = {0};
        int angles[3] = {0};
        int distanceIR[180] = {0};
        float objectWidths[3] = {0};
         cyBOT_Scan_t scan;
         cyBOT_Scan_t objects[3];
         cyBOT_Scan_t avgscan[20]; // Array of scan results
    while(1) {

 //char variable = uart_receive();
        //uart_sendChar(variable);
        //if (variable == 'm') {
            for(i = 0; i < 180; i += 3) {  // Fixed increment to i += 3
                int j;
                for (j = 0; j < 20; j++) {
                    cyBOT_Scan(i, &avgscan[j]);
                }
                int IR_avg = 0;
                int k;
                for( k = 0; k < 20; k++) {
                    IR_avg += avgscan[k].IR_raw_val;
                }
                distanceIR[i] = IR_avg / 20;

                if(i != 0 && abs(distanceIR[i] - distanceIR[i-1]) > 3) {
                    edges[i] = i;
                }
            }

            int k = 0;
            for(i = 0; i < 6; i += 2) {  // Process pairs of edges
                int angle = (edges[i+1] - edges[i]) / 2;  // Middle angle of the object
                angles[k] = angle;
                cyBOT_Scan(angle, &scan);
                objects[k] = scan;
                int distance = objects[k].sound_dist;
                objectWidths[k] = 2 * M_PI * distance * (angle * 2 / 360); // Correct width calculation
                k++;
            }

            // Find smallest object
            int smallestObject = 0;
            float smallestObjectWidth = objectWidths[0];
            for(i = 0; i < 3; i++) {
                if(smallestObjectWidth > objectWidths[i]) {
                    smallestObjectWidth = objectWidths[i];
                    smallestObject = i;
                }
            }

            // Make decision based on the smallest object
            if (angles[smallestObject] > 90) {
                turn_right(sensor_data, angles[smallestObject] - 90);
                move_forward(sensor_data, objects[smallestObject].sound_dist * 10);
            }
            else if (angles[smallestObject] < 90) {
                turn_left(sensor_data, 90 - angles[smallestObject]);
                move_forward(sensor_data, objects[smallestObject].sound_dist * 10);
            }
            else {
                move_forward(sensor_data, objects[smallestObject].sound_dist * 10);
            }

            char buffer[100]; // Make sure the buffer is large enough for your formatted string

            // Sending number of objects
            sprintf(buffer, "Number of objects: %d", 3);
            uart_sendStr(buffer);

            // Sending angles
            uart_sendStr("Angles: ");
            for (i = 0; i < 3; i++) {
                sprintf(buffer, "%d ", angles[i]);  // Format each angle value
                uart_sendStr(buffer);
            }

            // Sending widths
            uart_sendStr("Widths: ");
            for (i = 0; i < 3; i++) {
                sprintf(buffer, "%f ", objectWidths[i]);  // Format each width value
                uart_sendStr(buffer);
           // }
        }
    }
}
