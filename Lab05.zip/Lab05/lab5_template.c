/**
 * lab5_template.c
 *
 * Template file for CprE 288 Lab 5
 *
 * @author Zhao Zhang, Chad Nelson, Zachary Glanz
 * @date 08/14/2016
 *
 * @author Phillip Jones, updated 6/4/2019
 * @author Diane Rover, updated 2/25/2021, 2/17/2022
 */

#include "timer.h"
#include "lcd.h"

//#include "cyBot_uart.h"  // Functions for communicating between CyBot and Putty (via UART1)
                         // PuTTy: Baud=115200, 8 data bits, No Flow Control, No Parity, COM1

#include "cyBot_Scan.h"  // Scan using CyBot servo and sensors

#include "uart.h"
#warning "Possible unimplemented functions"
#define REPLACEME 0


/*void send_string(char *s){
    int i;
    for (i = 0; i < strlen(s); i++) {
        cyBot_sendByte(s[i]);
    }
}
*/


/*int main(void) {

	timer_init(); // Must be called before lcd_init(), which uses timer functions
	lcd_init();

  // initialize the cyBot UART1 before trying to use it

  // (Uncomment ME for UART init part of lab)
	 //cyBot_uart_init_clean();  // Clean UART1 initialization, before running your UART1 GPIO init code

	// Complete this code for configuring the GPIO PORTB part of UART1 initialization (your UART1 GPIO init code)
     /* SYSCTL_RCGCGPIO_R |= 0b000010;
      SYSCTL_RCGCUART_R |= 0b000010;
	    while ((SYSCTL_PRGPIO_R & 0b10) == 0) {};
		  GPIO_PORTB_DEN_R |= 0x03;
		  GPIO_PORTB_AFSEL_R |= 0x03;
       GPIO_PORTB_PCTL_R &= 0xFFFFFF00;    // Force 0's in the desired locations
      GPIO_PORTB_PCTL_R |= 0x00000011;     // Force 1's in the desired locations
*/

		 // Or see the notes for a coding alternative to assign a value to the PCTL field
//00010001
    // (Uncomment ME for UART init part of lab)
		 //uart_init();  // Complete the UART device configuration

		// Initialize the scan
	   //cyBOT_init_Scan(0b0111);
		// Remember servo calibration function and variables from Lab 3


	    /*char variable =  cyBot_getByte();
	   cyBot_sendByte(variable);
	    lcd_putc(variable);
	   send_string("got an m");

	// YOUR CODE HERE
	  right_calibration_value = 337750;
	       left_calibration_value = 1330000;
	       int i = 0;
	       int j = 0;
	       int m = 0;
	       char buffer[100];
	       cyBOT_Scan_t scan;
	       int distances[60];
	       int objects[60];

	while(1)
	{

	    int i;

	    char variable =  uart_receive_nonblocking();
	    if(variable == 'g'){
	        for(i=0; i<= 180; i+=3){

	                char v =  uart_receive_nonblocking();
	                if(v == 's'){
	                    break;
	                }
	                else{
	                    cyBOT_Scan(i, &scan);

	                 //cyBot_sendByte(i);
	                //cyBot_sendByte((int)scan.sound_dist);
	                distances[m] = (int)scan.sound_dist;
	                m ++;



	                }
	            }
	    }
	    uart_sendChar(variable);
	    lcd_putc(variable);
	    uart_sendStr("\r\n");
	    if(i > 180){
	        i = 0;
	    }
i++;
	           }
      // YOUR CODE HERE


	}
*/
