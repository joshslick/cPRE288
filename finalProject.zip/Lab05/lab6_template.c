#include "Timer.h"
#include "lcd.h"
#include "cyBot_Scan.h"
//#include "uart.h"
#include "open_interface.h"
#include "movement.h"
#include "uart-interrupt.h"
#include "adc.h"
#include <math.h>

#define REPLACEME 0
void Delay(uint32_t time)
{
uint32_t Loop;
for (Loop = 0; Loop < time; Loop++) {}
}

float a = 0.0002;
float b = -0.5;
float c = 50;

float estimate_distance(uint16_t adc_value) {

    return (319.729 * exp(-0.00200072 * (adc_value)) + 9.327);
}


/*int main() {

    uart_interrupt_init();
    timer_init();
    lcd_init();
    adc_init();


    cyBOT_init_Scan(0b0111);

    right_calibration_value = 337750;
    left_calibration_value = 1330000;

    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
        volatile int i = 0;
        t i;
        int objectCounter = 0;
        int edges[90] = {0};
        int angles[35] = {0};
        int distanceIR[90] = {0};
        double objectWidths[35] = {0};
         cyBOT_Scan_t scan;
         cyBOT_Scan_t objects[35];
         cyBOT_Scan_t avgscan[3]; // Array of scan results
         oi_setWheels(0, 0);
         uint32_t adcValue;
        while(1) {


//byte_received = uart_receive();

            int adcSum = 0;
            float  averageAdcValue = 0;

                for (i = 0; i < 16; i++) {
                    adcValue = adc_read();
                    adcSum += adcValue;
                }


                averageAdcValue = (float)adcSum / 16.0;


                float estimated_distance = estimate_distance((uint16_t)averageAdcValue);
                    char buffer[100];
                    char buffer1[100];
                   sprintf(buffer, "Data: %d ", adcValue);
                   sprintf(buffer1, "         Dist: %.2f", estimated_distance);
                   uart_sendStr(buffer);
           lcd_setCursorPos(0, 0);
           lcd_printf(strcat(buffer, buffer1));

           //lcd_setCursorPos(1, 0);
           //lcd_printf(buffer1);


            Delay(500000);
        }
            //lab 7
            byte_received = uart_receive();

        if (byte_received == 'm') {
            int counter = 0;
            for(i = 0; i < 180; i += 2) {  // Fixed increment to i += 3
                int j;
                for (j = 0; j < 2; j++) {
                    cyBOT_Scan(i, &avgscan[j]);
                }
                int IR_avg = 0;
                int k;
                for( k = 0; k < 2; k++) {
                    IR_avg += avgscan[k].IR_raw_val;
                }
                distanceIR[counter] = IR_avg / 2;



                if(counter != 0 && abs(distanceIR[counter] - distanceIR[counter-1]) > 100) {
                    edges[objectCounter] = i;
                    objectCounter++;
                }
                counter++;
            }

            int k = 0;
            for(i = 0; i < objectCounter; i += 2) {  // Process pairs of edges
                int angle = (edges[i+1] - edges[i]) / 2;  // Middle angle of the object
                angles[k] = angle + edges[i];
                cyBOT_Scan(angles[k], &scan);
                objects[k] = scan;
                int distance = objects[k].sound_dist;
                objectWidths[k] = 2.0 * M_PI * distance * (angle * 2.0 / 360.0); // Correct width calculation
                k++;
            }

            // Find smallest object
            int smallestObject = 0;
            double smallestObjectWidth = objectWidths[0];
            for(i = 0; i < objectCounter/2; i++) {
                if(smallestObjectWidth > objectWidths[i]) {
                    smallestObjectWidth = objectWidths[i];
                    smallestObject = i;
                }
            }

            char buffer[100]; // Make sure the buffer is large enough for your formatted string

            sprintf(buffer, "Number of objects: %d ", (objectCounter/2));
            uart_sendStr(buffer);

            // Sending angles
            uart_sendStr("Angles: ");
            for (i = 0; i < objectCounter / 2; i++) {
                sprintf(buffer, "%d ", angles[i]);  // Format each angle value
                uart_sendStr(buffer);
            }

            // Sending widths
            uart_sendStr("Widths: ");
            for (i = 0; i < objectCounter / 2; i++) {
                sprintf(buffer, "%f ", objectWidths[i]);  // Format each width value
                uart_sendStr(buffer);
           }

                            // Move towards the smallest object
                            if(angles[smallestObject] < 90) {
                                turn_right(sensor_data, angles[smallestObject] - 90);
                                move_forward(sensor_data, objects[smallestObject].sound_dist  - 5);
                                oi_setWheels(0, 0);
                            }
                            else if(angles[smallestObject] > 90) {
                                turn_left(sensor_data, 90 - angles[smallestObject]);
                                move_forward(sensor_data, objects[smallestObject].sound_dist  - 5);
                                oi_setWheels(0, 0);
                            }
                            else {
                                move_forward(sensor_data, objects[smallestObject].sound_dist - 5);
                                oi_setWheels(0, 0);
                            }





                        oi_setWheels(0, 0);  // Stop the robot
                    }
        oi_setWheels(0, 0);
                }

            }
            */


