/**
 * @file lab9_template.c
 * @author
 * Template file for CprE 288 Lab 9
 */

#include "Timer.h"
#include "lcd.h"
#include "servo.h"
#include "button.h"
// Uncomment or add any include directives that are needed

#warning "Possible unimplemented functions"
#define REPLACEME 0

int main(void) {
	timer_init(); // Must be called before lcd_init(), which uses timer functions
	lcd_init();
	button_init();
	int button = 0;
	int angle = 0;
	//ping_init();
servo_init();
servo_move(90);
timer_waitMillis(1000);
servo_move(30);
timer_waitMillis(1000);
servo_move(150);
timer_waitMillis(1000);
servo_move(90);
angle = 90;
	// YOUR CODE HERE

    //right_calibration_value = 337750;
    //left_calibration_value = 1330000;

    //oi_t *sensor_data = oi_alloc();
    //oi_init(sensor_data);
        volatile int i = 0;
        /*t i;
        int objectCounter = 0;
        int edges[90] = {0};
        int angles[35] = {0};
        int distanceIR[90] = {0};
        double objectWidths[35] = {0};
         cyBOT_Scan_t scan;
         cyBOT_Scan_t objects[35];
         cyBOT_Scan_t avgscan[3]; // Array of scan results
         oi_setWheels(0, 0);*/
         uint32_t ping;
	while(1)
	{
	    button = button_getButton();
	    timer_waitMillis(100);
	    angle = button1(button, angle);
	    button = 0;
      // YOUR CODE HERE

// lab 9

	    /*timer_waitMillis(1000);
	            float distance = 0;
	            distance = ping_getDistance();
	            lcd_printf( "Distance: %.2f cm", distance);
	            timer_waitMillis(1500);
	            lcd_printf("Pulse Width: %.2f" , getPulsewidth());
	            timer_waitMillis(1500);
	            lcd_printf("Overflow: %.2f" , getOverflow());
	            */
	}

}
