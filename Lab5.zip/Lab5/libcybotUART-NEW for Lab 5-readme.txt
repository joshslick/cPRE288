
libcybotUART.txt is a pre-compiled library for CyBot/Human UART communication. 
The file extension must be changed from .txt to .lib after copying into your folder.

NOTE: This is a new library with new functions compared to the library provided in previous labs. See the header file. 

In Lab 5, use the new cybotUART header and library files.
