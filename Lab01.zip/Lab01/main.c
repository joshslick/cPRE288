
#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_uart.h"
#include "cyBot_Scan.h"

/**
 * main.c
 */

void send_string(char *s){


    int i;
    for (i=0; i < strlen(s); i++){
        cyBot_sendByte(s[i]);
    }

}

int FindObject(int objects[], int start){
    int i;
    int objectEnd;
    for(i = start; i < sizeof(objects); i++){
        if(objects[i+1] - objects[i] > 10){
            objectEnd += i*3;
            break;
        }


    }
    return objectEnd;
}
//0 degrees: 332500

// 180 degrees:831250
/*int main (void) {
    /*lcd_init();

     cyBot_uart_init();

 char variable =   cyBot_getByte();
cyBot_sendByte(variable);
 lcd_putc(variable);
send_string("got an m");

    timer_init();
    lcd_init();
    cyBot_uart_init();
    cyBOT_init_Scan(0b0111);

    right_calibration_value = 337750;
    left_calibration_value = 1330000;
    int i = 0;
    int j = 0;
    int m = 0;
    char buffer[100];
    cyBOT_Scan_t scan;
    int distances[60];
    int objects[60];
    char variable =   cyBot_getByte();
    cyBot_sendByte(variable);

if(variable == 'm'){
    for(i=0; i<= 180; i+=3){
        cyBOT_Scan(i, &scan);

         //cyBot_sendByte(i);
        //cyBot_sendByte((int)scan.sound_dist);
        distances[m] = (int)scan.sound_dist;
        m ++;

         sprintf(buffer, "%d : %.2f cm\r\n", i, scan.sound_dist);
         send_string(buffer);


    }
/*
timer_init();
   lcd_init();
   cyBOT_init_Scan(0b0111);
   cyBOT_SERVO_cal();


    for(i=0; i < 60; i++){
        if((int)distances[i] < 50){
            objects[j] = i * 3;
            j++;
        }
    }



    int object1 = FindObject(objects, 0);
    int object2 = FindObject(objects, object1);

    if(object1 < object2){
        cyBOT_Scan(object1, &scan);
    }
    else{
        cyBOT_Scan(object2, &scan);
    }


    sprintf(buffer, "Objects: 2\r\n Object1: Width: %d Distance: %d cm\r\n Object2: Width: %d Distance: %d cm\r\n", (objects[object1] - objects[0]), distances[object1], (objects[object2]-objects[object1]), distances[object2]);
    send_string(buffer);

}
return 0;


}
*/
