
#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_uart.h"
#include "cyBot_Scan.h"

/**
 * main.c
 */

void send_string(char *s){


    int i;
    for (i=0; i < strlen(s); i++){
        cyBot_sendByte(s[i]);
    }

}

int main (void) {
    /*lcd_init();

     cyBot_uart_init();

 char variable =   cyBot_getByte();
cyBot_sendByte(variable);
 lcd_putc(variable);
send_string("got an m");*/
    cyBot_uart_init();
    cyBOT_init_Scan(0b0111);
    cyBOT_Scan_t x;
    cyBOT_Scan(90, &x);

return 0;


}

