
#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
/**
 * main.c
 */

int main (void) {
    timer_init(); // Initialize Timer, needed before any LCD screen functions can be called
                      // and enables time functions (e.g. timer_waitMillis)

        lcd_init();   // Initialize the LCD screen.  This also clears the screen.

    oi_t *sensor_data = oi_alloc(); // do this only once at start of main()
    oi_init(sensor_data); // do this only once at start of main()
    lcd_printf("driving");
    //move_forward(sensor_data, 1000);
    int i;
    for (i=0; i < 4; i++) {
            move_forward(sensor_data, 500);  // Move forward 50 cm (500 mm)
            turn_right(sensor_data, 90);     // Turn 90 degrees to the right

        }



    /*int distance = 0;
    while(distance < 2000){
        oi_update(sensor_data);
    move_forward(sensor_data, 2000);
    oi_update(sensor_data);

     if (sensor_data->bumpLeft) {
         oi_setWheels(0, 0);
        move_forward(sensor_data, -150);
        turn_right(sensor_data, 90);
        move_forward(sensor_data, 250);
        turn_left(sensor_data, 90);



    }
    if (sensor_data->bumpRight) {
        oi_setWheels(0, 0);
            move_forward(sensor_data, -150);
            turn_left(sensor_data, 90);
            move_forward(sensor_data, 250);
            turn_right(sensor_data, 90);



        }
    if ((sensor_data->bumpLeft && sensor_data->bumpRight)) {
            move_forward(sensor_data, -150);
            turn_right(sensor_data, 90);
            move_forward(sensor_data, 250);

            turn_left(sensor_data, 90);


        }
    distance += sensor_data->distance;
    oi_free(sensor_data);
    return 0;
    }

*/



}
