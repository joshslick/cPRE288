
#include "Timer.h"
#include "lcd.h"
#include "open_interface.h"
#include "movement.h"
#include "cyBot_uart.h"
#include "cyBot_Scan.h"

/**
 * main.c
 */

void send_string(char *s){


    int i;
    for (i=0; i < strlen(s); i++){
        cyBot_sendByte(s[i]);
    }

}
//0 degrees: 332500

// 180 degrees:831250
int main (void) {
    /*lcd_init();

     cyBot_uart_init();

 char variable =   cyBot_getByte();
cyBot_sendByte(variable);
 lcd_putc(variable);
send_string("got an m");
*/
    timer_init();
    lcd_init();
    cyBot_uart_init();
    cyBOT_init_Scan(0b0111);

    right_calibration_value = 337750;
    left_calibration_value = 1330000;
    int i;
    char buffer[100];
    cyBOT_Scan_t scan;

    char variable =   cyBot_getByte();
    cyBot_sendByte(variable);

if(variable == 'm'){
    for(i=0; i<= 180; i+=5){
        cyBOT_Scan(i, &scan);

        cyBot_sendByte(i);
         cyBot_sendByte((int)scan.sound_dist);

         sprintf(buffer, "%d : %.2f cm\r\n", i, scan.sound_dist);
         send_string(buffer);


    }
/*
timer_init();
   lcd_init();
   cyBOT_init_Scan(0b0111);
   cyBOT_SERVO_cal();
*/

}
return 0;


}

