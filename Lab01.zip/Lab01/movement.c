/*
 * movement.c
 *
 *  Created on: Feb 4, 2025
 *      Author: jossli01
 */


#include "open_interface.h"




double move_backward(oi_t *self, double distance_mm)
{
oi_setWheels(-500, -500); // set the speed of both wheels
double sum = 0;
while (sum < distance_mm) {
oi_update(self);
sum += fabs(self->distance);
// optional check for bump sensors
}
oi_setWheels(0, 0); // stop the robot

return sum;
}






void turn_right(oi_t *self, double degrees)
{
    double angle = 0.0; // Record the starting angle
       oi_setWheels(-300, 300);  // Set the robot to turn right (positive speed for left wheel, negative for right wheel)

       while (angle < degrees) {
           oi_update(self);  // Update sensor data to track the angle
           angle += fabs(self->angle);
       }
       oi_setWheels(0, 0);  // Stop the robot after turning
   }
void turn_left(oi_t *self, double degrees) {
    double angle = 0.0; // Record the starting angle
    oi_setWheels(300, -300);  // Set the robot to turn left (negative speed for left wheel, positive for right wheel)

    while (angle < degrees) {
               oi_update(self);  // Update sensor data to track the angle
               angle += fabs(self->angle);
           }
    oi_setWheels(0, 0);  // Stop the robot after turning
}

double move_forward(oi_t *self, double distance_mm)
{
oi_setWheels(500, 500); // set the speed of both wheels
double sum = 0;

while (sum < distance_mm) {
oi_update(self);
sum += fabs(self->distance);
    if (self->bumpLeft) {
        //oi_setWheels(0, 0);
        move_backward(self, 150);
        turn_right(self, 90);
        move_forward(self, 250);
        turn_left(self, 90);
        oi_setWheels(500, 500);
        sum -= 150;
    }
    if (self->bumpRight) {
        //oi_setWheels(0, 0);
        move_backward(self, 150);
        turn_left(self, 90);
        move_forward(self, 250);
        turn_right(self, 90);
        oi_setWheels(500, 500);
        sum -= 150;
    }


// optional check for bump sensors
}
oi_setWheels(0, 0); // stop the robot

return sum;
}




