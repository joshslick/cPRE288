/*
 * movement.h
 *
 *  Created on: Feb 4, 2025
 *      Author: jossli01
 */

#ifndef MOVEMENT_H_
#define MOVEMENT_H_

void move_forward(oi_t *self, double distance_mm);

void turn_right(oi_t *self, double degrees);

void turn_left(oi_t *self, double degrees);

#endif /* MOVEMENT_H_ */
